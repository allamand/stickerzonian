// amplify/backend/function/S3Triggerxxxxxxx/src/index.js

const AWS = require('aws-sdk');
const S3 = new AWS.S3({ signatureVersion: 'v4' });
const DynamoDBDocClient = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });
const uuidv4 = require('uuid/v4');

/*
Note: Sharp requires native extensions to be installed in a way that is compatible
with Amazon Linux (in order to run successfully in a Lambda execution environment).

If you're not working in Cloud9, you can follow the instructions on http://sharp.pixelplumbing.com/en/stable/install/#aws-lambda how to install the module and native dependencies.
*/
const Sharp = require('sharp');

// We'll expect these environment variables to be defined when the Lambda function is deployed
const THUMBNAIL_WIDTH = parseInt(process.env.THUMBNAIL_WIDTH, 10);
const THUMBNAIL_HEIGHT = parseInt(process.env.THUMBNAIL_HEIGHT, 10);
const DYNAMODB_PHOTOS_TABLE_NAME = process.env.DYNAMODB_PHOTOS_TABLE_ARN.split('/')[1];

function storeStickerInfo(item) {
  const params = {
    Item: item,
    TableName: DYNAMODB_PHOTOS_TABLE_NAME
  };
  console.log("store " + item);
  return DynamoDBDocClient.put(params).promise();
}

async function getMetadata(bucketName, key) {
  const headResult = await S3.headObject({ Bucket: bucketName, Key: key }).promise();
  return headResult.Metadata;
}

function thumbnailKey(filename) {
  return `public/resized/${filename}`;
}

function fullsizeKey(filename) {
  return `public/${filename}`;
}

function makeThumbnail(sticker) {
  return Sharp(sticker).resize(THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT).toBuffer();
}

async function resize(bucketName, key) {
  const originalSticker = (await S3.getObject({ Bucket: bucketName, Key: key }).promise()).Body;
  const originalStickerName = key.replace('uploads/', '');
  const originalStickerDimensions = await Sharp(originalSticker).metadata();

  const thumbnail = await makeThumbnail(originalSticker);

  await Promise.all([
    S3.putObject({
      Body: thumbnail,
      Bucket: bucketName,
      Key: thumbnailKey(originalStickerName),
    }).promise(),

    S3.copyObject({
      Bucket: bucketName,
      CopySource: bucketName + '/' + key,
      Key: fullsizeKey(originalStickerName),
    }).promise(),
  ]);

  await S3.deleteObject({
    Bucket: bucketName,
    Key: key
  }).promise();

  return {
    StickerId: originalStickerName,

    thumbnail: {
      key: thumbnailKey(originalStickerName),
      width: THUMBNAIL_WIDTH,
      height: THUMBNAIL_HEIGHT
    },

    fullsize: {
      key: fullsizeKey(originalStickerName),
      width: originalStickerDimensions.width,
      height: originalStickerDimensions.height
    }
  };
}

async function processRecord(record) {
  const bucketName = record.s3.bucket.name;
  const key = record.s3.object.key;

  if (key.indexOf('uploads') != 0) return;

  const metadata = await getMetadata(bucketName, key);
  const sizes = await resize(bucketName, key);
  const id = uuidv4();
  const item = {
    id: id,
    owner: metadata.owner,
    stickerDeckId: metadata.deckid,
    bucket: bucketName,
    thumbnail: sizes.thumbnail,
    fullsize: sizes.fullsize,
    createdAt: new Date().getTime()
  };
  await storeStickerInfo(item);
}

exports.handler = async(event, context, callback) => {
  try {
    event.Records.forEach(processRecord);
    callback(null, { status: 'Sticker Processed' });
  }
  catch (err) {
    console.error(err);
    callback(err);
  }
};
